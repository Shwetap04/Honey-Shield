import random
import datetime
from uuid import uuid4

def generate_synthetic_chat_log():
    users = ["alice", "bob", "charlie", "david"]
    manipulation_phrases = [
        "You can trust me completely", "Don’t tell anyone about this",
        "Just send me your details", "It’s urgent, please act now",
        "You owe me this"
    ]
    casual_phrases = [
        "How was your day?", "Let's meet for coffee tomorrow.",
        "What's your plan for the weekend?", "Did you complete the task?"
    ]

    platforms = ["whatsapp", "telegram", "instagram", "signal"]
    devices = ["android", "ios", "web"]

    sender = random.choice(users)
    receiver = random.choice([u for u in users if u != sender])
    
    message_count = random.randint(4, 8)

    def gen_message():
        risky = random.random() < 0.3  # 30% chance of being risky
        text = random.choice(manipulation_phrases if risky else casual_phrases)
        return {
            "sender": random.choice([sender, receiver]),
            "text": text,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "manipulation_flag": risky,
            "sentiment": random.choice(["positive", "neutral", "negative"]),
            "device": random.choice(devices)
        }

    chat_log = {
        "chat_id": str(uuid4()),
        "participants": [sender, receiver],
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "platform": random.choice(platforms),
        "messages": [gen_message() for _ in range(message_count)],
        "session_meta": {
            "encryption": random.choice(["E2EE", "None"]),
            "suspicious_score": round(random.uniform(0, 1), 2)
        }
    }

    return chat_log
